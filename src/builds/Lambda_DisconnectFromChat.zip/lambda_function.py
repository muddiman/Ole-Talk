import json
import boto3
from time import ctime
from libs import standard_response_lib as std_lib
from libs import database_lib as dlib
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key, Attr


AWS_REGION='us-east-1'
DB=boto3.resource(
            'dynamodb',
            region_name=AWS_REGION
        )
  

def lambda_handler(event, context):
    # TODO implement
    conn_id = event['requestContext']['connectionId']
    # room = get_room_id(conn_id)
    # user_id = json.loads(event['body'])['userid']
    # close connection (delete db entry) 
    statusCode, statusMsg = disconnect_from_server(conn_id)
    return std_lib.std_response(statusCode, statusMsg)


def disconnect_from_server(connectId):
    chat_db = dlib.Dbase('ChatSvrConnections')
    return chat_db.delete_record('connectionId', connectId)

                
def broadcastMsg(userid, msg):
    Item={
        "timestamp": ctime(),
        "user": userid,
        "text": msg
    }    
    chat_db = dlib.Dbase('ChatSvrConnections')
    return chat_db.insert_record(**Item)
